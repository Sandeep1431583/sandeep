import os

ae_ops_project_dict = {
    "hcb-dev": "anbc-hcb-dev",
    "hcb-test": "anbc-hcb-test",
    "hcb-prod": "anbc-hcb-prod"
}

ae_ops_project = ae_ops_project_dict[os.environ["AE_OPS_ENV"]]
