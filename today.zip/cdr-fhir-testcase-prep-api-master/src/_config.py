from dynaconf import Dynaconf

settings = Dynaconf(
    settings_files=['src/settings.yaml'],
    preload=['src/settings.yaml'],
    load_dotenv=True,
    envvar_prefix=False
)
