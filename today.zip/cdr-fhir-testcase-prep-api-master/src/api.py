import os
from typing import List
from fastapi import FastAPI
from ._config import settings
import pandas as pd
from src.backend.core import Core
from src.backend.llm import llm
import json
from src.backend.config import load_config
from src.backend.data import FHIR_Resource_list, Layout_list
import vertexai
from google.auth import default
from google.oauth2 import service_account
from vertexai.generative_models import GenerativeModel, Part, SafetySetting
from langchain_google_vertexai import VertexAI
from fastapi import Depends, FastAPI, Query, Response, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic
from fastapi.responses import JSONResponse
from cachetools import cached, TTLCache
from pydantic import BaseModel
from google.cloud.exceptions import GoogleCloudError
from ._logging import logging
from src._config import settings
from google.cloud import bigquery
from pydantic import BaseModel, conint, Field
import requests
from typing import Optional, List, Dict

app = FastAPI(title="cdr testcase service", description="This service is used for cdr FHIR mapping", )

class TestCaseParams(BaseModel):
    layout_type: Optional[str] = None
    fhir_resource: Optional[str] = None
    testcase_type: Optional[str] = None
    file_content: Dict[str, str]    

@app.post('/GenerateTestCase_v2api/')
def GenerateTestCase_v1(inputParams: TestCaseParamsNew):
    try:     
        project_id = os.environ['project_id']
        location = os.environ['location']
        service_account_path =os.environ['service_account_path']

        llm.initialize_vertex_ai(project_id, location, service_account_path)
        response = llm.call_gemini_langgraph(inputParams.concat_prompt, project_id, location) 
        return {'Response' : response}
    except Exception as e:
        return {'Error': str(e)} 
