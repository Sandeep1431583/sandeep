import logging
from logging import config
from ._config import settings

config.dictConfig(settings.logging)
