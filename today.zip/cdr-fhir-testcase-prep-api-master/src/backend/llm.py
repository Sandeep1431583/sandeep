import vertexai
from google.auth import default
from google.oauth2 import service_account
from vertexai.generative_models import GenerativeModel, Part, SafetySetting
from langchain_google_vertexai import VertexAI

class llm:

    def initialize_vertex_ai(project_id, location, service_account_path):
        """Initializes Vertex AI. Uses service account if provided, otherwise ADC."""
        if service_account_path:
            credentials = service_account.Credentials.from_service_account_file(service_account_path)
            vertexai.init(project=project_id, location=location, credentials=credentials) # this is not strictly needed, but you can
            print("Vertex AI initialized using service account.")

        else:
            credentials, project = default()  # Uses Application Default Credentials
            vertexai.init(project=project_id, location=location, credentials=credentials)
            print("Vertex AI initialized using Application Default Credentials.")

    def initialize_llm(project_id, location):
        """Initializes the Gemini LLM through LangChain's VertexAI integration."""
        vertexai.init(project=project_id, location=location)

        llm = VertexAI(
            model_name="gemini-1.5-pro-002",
            max_output_tokens=8192,
            temperature=0.1,
            top_p=0.95,
        )
        return llm
    

    def call_gemini_langgraph(Concat_prompt, project_id, location):
        """Calls Gemini using LangGraph."""
       
        llm_call = llm.initialize_llm(project_id, location)
        # Prepare the initial state for the graph
        #initial_state = {
            #"system_prompt": formatted_sys_prompt,
            #"user_prompt": formatted_user_prompt,
           # "prompt": Concat_prompt,
           # "llm_output": ""
        #}
        results = llm_call.invoke(Concat_prompt)
        return results