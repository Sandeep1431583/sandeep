FHIR_Resource_list = [
                        "AllergyIntolerance",
                        "CareTeam",
                        "Communication",
                        "Composition",
                        "Condition",
                        "Coverage",
                        "Device",
                        "DeviceRequest",
                        "DiagnosticReport",
                        "DocumentReference(CDA)",
                        "DocumentReference(Notes)",
                        "Encounter",
                        "FamilyMemberHistory",
                        "Goal",
                        "Immunization",
                        "Location",
                        "MedicationAdministration",
                        "MedicationRequest",
                        "MedicationStatement",
                        "Observation(FunctionalStatus)",
                        "Observation(Results)",
                        "Observation(SocialHistory)",
                        "Observation(VitalSigns)",
                        "Organization",
                        "Patient",
                        "Practitioner",
                        "PractitionerRole",
                        "Procedure",
                        "Provenance",
                        "ServiceRequest",
                        "Specimen",         
                     ]   

Layout_list = [
    "ADT",
    "CCDA",
]


expected_output_format = {
  "TestCases": [
    {
      "TestCaseID": "A unique identifier for the test case, combining type, subtype, and a sequential number (e.g., TC_001_Functional_Positive).",
      "Subtype": "Specifies whether the test case is Positive or Negative.",
      "TestCaseType": "Specifies the type of test case (e.g., Functional, Regression, Edge).",
      "TestCaseDescription": "A concise description of the objective or purpose of the test case.",
      "ExpectedOutput": "The expected FHIR resource and system behavior after executing the test case.",
      "TestSteps": [
        "A list of detailed steps to execute the test case in sequence.",
        "Each step describes an action or input required for the test."
      ],
      "PassFailCriteria": {
        "Pass": "Clear criteria that define what constitutes a successful test case execution.",
        "Fail": "Clear criteria that define what constitutes a failed test case execution."
      }
    },
    {
      "TestCaseID": "A unique identifier for the test case, combining type, subtype, and a sequential number (e.g., TC_002_Functional_Negative).",
      "Subtype": "Specifies whether the test case is Positive or Negative.",
      "TestCaseType": "Specifies the type of test case (e.g., Functional, Regression, Edge).",
      "TestCaseDescription": "A concise description of the objective or purpose of the test case.",
      "ExpectedOutput": "The expected FHIR resource and system behavior after executing the test case.",
      "TestSteps": [
        "A list of detailed steps to execute the test case in sequence.",
        "Each step describes an action or input required for the test."
      ],
      "PassFailCriteria": {
        "Pass": "Clear criteria that define what constitutes a successful test case execution.",
        "Fail": "Clear criteria that define what constitutes a failed test case execution."
      }
    },
  ],
  "MissingTestCases": [
    {
      "Attribute": "The name of the attribute or element for which a test case is missing.",
      "Reason": "A detailed explanation of why the test case is missing or could not be created."
    }
  ],
  "BreakingTestCases": [
    {
      "OriginalTestCaseID": "The unique identifier of the original test case that is breaking.",
      "ReasonForBreakage": [
        "A list of reasons explaining why the test case is breaking, including mapping or attribute-level issues.",
        "Each reason provides specific details about the breakage."
      ]
    }
  ],
  "StatisticalSummary": {
    "MappingRows": "The total number of rows in the mapping CSV file.",
    "UniqueAttributes": "The number of unique attributes listed in the layout attribute column.",
    "NumberOfTestCasesCreated": "The total number of test cases created based on the mapping.",
    "NumberOfTestCasesModified": "The total number of test cases that were updated or modified.",
    "TestCaseTypeBreakdown": {
      "Functional": "The number of functional test cases created.",
      "Regression": "The number of regression test cases created.",
      "Edge": "The number of edge test cases created."
    },
    "SubtypeBreakdown": {
      "Positive": "The number of positive test cases created.",
      "Negative": "The number of negative test cases created."
    },
    "AttributeTestCaseDetails": [
      {
        "Attribute": "AttributeName1",
        "NumberOfTestCases": "The number of test cases created for this specific attribute."
      },
      {
        "Attribute": "AttributeName2",
        "NumberOfTestCases": "The number of test cases created for this specific attribute."
      },
    ]
  }
}
