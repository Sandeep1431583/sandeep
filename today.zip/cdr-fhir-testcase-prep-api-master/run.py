import uvicorn
import os
import sys
sys.path.append(os.getcwd())
from src._config import settings
from src._logging import logging
from src.app import app

log = logging.getLogger(__name__)

port = settings.listener.port


def main():
    log.info(f"listening on port={port}")
    uvicorn.run(app, host='0.0.0.0', port=port)  # for local testing

if __name__ == "__main__":
    main()
